#include "Animal.h"

bool Animal::IsHousePet(){ return isHousePet;};

std::string Animal::GetLatinName(){ return LATIN_NAME;};

std::string Animal::GetCommonName(){ return COMMON_NAME;};

double Animal::GetWheight(){ return WHEIGHT;};


