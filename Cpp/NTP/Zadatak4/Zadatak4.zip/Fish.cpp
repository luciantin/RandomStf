#include "Fish.h"

bool Shark::IsDangerous(){ return isDangerous;}

bool WhiteCatFish::IsCatFish(){ return isCat & isFish;}
bool WhiteCatFish::IsCat(){ return  isCat;}
bool WhiteCatFish::IsFish(){ return isFish;}